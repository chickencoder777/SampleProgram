/*
    Jessie Ritter
    October 20, 2019.
    This program accepts user input on the informations for a passenger for an airline company. It then may output the passenger's
    information in a variety of forms based on the user's choice of actions.
 */

// An importation is made so that the array lists can be made.
import java.util.ArrayList;

public class Ritter_FlightFrm extends javax.swing.JFrame {

    // The array lists are declared.
    ArrayList<String> firstNameArray = new ArrayList();
    ArrayList<String> lastNameArray = new ArrayList();
    ArrayList<Integer> week1Array = new ArrayList();
    ArrayList<Integer> week2Array = new ArrayList();
    ArrayList<Integer> week3Array = new ArrayList();
    ArrayList<Integer> week4Array = new ArrayList();

    public Ritter_FlightFrm() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        lblTitle = new javax.swing.JLabel();
        lblFirstName = new javax.swing.JLabel();
        lblLastName = new javax.swing.JLabel();
        lblWeek1 = new javax.swing.JLabel();
        lblWeek2 = new javax.swing.JLabel();
        lblWeek3 = new javax.swing.JLabel();
        lblWeek4 = new javax.swing.JLabel();
        txtFirstName = new javax.swing.JTextField();
        txtLastName = new javax.swing.JTextField();
        txtWeek1 = new javax.swing.JTextField();
        txtWeek2 = new javax.swing.JTextField();
        txtWeek3 = new javax.swing.JTextField();
        txtWeek4 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtOutput = new javax.swing.JTextArea();
        btnAddCustomer = new javax.swing.JButton();
        btnDisplayAll = new javax.swing.JButton();
        btnDisplayCustomersTotalPoints = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        lblSubtitle = new javax.swing.JLabel();
        lblRedPlanePic = new javax.swing.JLabel();
        lblBluePlanePic = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Tempus Sans ITC", 1, 36)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(0, 0, 153));
        lblTitle.setText("Airline Points:");

        lblFirstName.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblFirstName.setForeground(new java.awt.Color(0, 0, 153));
        lblFirstName.setText("First Name:");

        lblLastName.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblLastName.setForeground(new java.awt.Color(153, 0, 0));
        lblLastName.setText("Last Name:");

        lblWeek1.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblWeek1.setForeground(new java.awt.Color(0, 0, 153));
        lblWeek1.setText("Week 1:");

        lblWeek2.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblWeek2.setForeground(new java.awt.Color(153, 0, 0));
        lblWeek2.setText("Week 2:");

        lblWeek3.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblWeek3.setForeground(new java.awt.Color(0, 0, 153));
        lblWeek3.setText("Week 3:");

        lblWeek4.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblWeek4.setForeground(new java.awt.Color(153, 0, 0));
        lblWeek4.setText("Week 4:");

        txtFirstName.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtFirstName.setForeground(new java.awt.Color(51, 51, 255));

        txtLastName.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtLastName.setForeground(new java.awt.Color(51, 51, 255));

        txtWeek1.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtWeek1.setForeground(new java.awt.Color(51, 51, 255));

        txtWeek2.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtWeek2.setForeground(new java.awt.Color(51, 51, 255));

        txtWeek3.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtWeek3.setForeground(new java.awt.Color(51, 51, 255));

        txtWeek4.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        txtWeek4.setForeground(new java.awt.Color(51, 51, 255));

        txtOutput.setColumns(20);
        txtOutput.setFont(new java.awt.Font("Tempus Sans ITC", 0, 16)); // NOI18N
        txtOutput.setForeground(new java.awt.Color(51, 51, 255));
        txtOutput.setRows(5);
        jScrollPane1.setViewportView(txtOutput);

        btnAddCustomer.setBackground(new java.awt.Color(102, 153, 255));
        btnAddCustomer.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        btnAddCustomer.setForeground(new java.awt.Color(255, 255, 255));
        btnAddCustomer.setText("Add Customer");
        btnAddCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCustomerActionPerformed(evt);
            }
        });

        btnDisplayAll.setBackground(new java.awt.Color(102, 153, 255));
        btnDisplayAll.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        btnDisplayAll.setForeground(new java.awt.Color(255, 255, 255));
        btnDisplayAll.setText("Display All");
        btnDisplayAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayAllActionPerformed(evt);
            }
        });

        btnDisplayCustomersTotalPoints.setBackground(new java.awt.Color(102, 153, 255));
        btnDisplayCustomersTotalPoints.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        btnDisplayCustomersTotalPoints.setForeground(new java.awt.Color(255, 255, 255));
        btnDisplayCustomersTotalPoints.setText("Display Customer's Total Points");
        btnDisplayCustomersTotalPoints.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayCustomersTotalPointsActionPerformed(evt);
            }
        });

        btnExit.setBackground(new java.awt.Color(255, 255, 255));
        btnExit.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        btnExit.setForeground(new java.awt.Color(255, 0, 0));
        btnExit.setText("<-Exit->");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        lblSubtitle.setFont(new java.awt.Font("Tempus Sans ITC", 0, 18)); // NOI18N
        lblSubtitle.setForeground(new java.awt.Color(204, 0, 0));
        lblSubtitle.setText("Enter in all of the following fields, filling out the number of points per week in integer form (whole numbers).");

        lblRedPlanePic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Plane Picture For Flight Program.png"))); // NOI18N
        lblRedPlanePic.setText("jLabel9");

        lblBluePlanePic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Picture Of Plane For Points Program.PNG"))); // NOI18N
        lblBluePlanePic.setText("jLabel10");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblWeek4)
                            .addComponent(lblWeek3)
                            .addComponent(lblWeek2)
                            .addComponent(lblWeek1)
                            .addComponent(lblLastName)
                            .addComponent(lblFirstName))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtFirstName)
                            .addComponent(txtLastName)
                            .addComponent(txtWeek4)
                            .addComponent(txtWeek3)
                            .addComponent(txtWeek1)
                            .addComponent(txtWeek2, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(104, 104, 104)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addComponent(lblRedPlanePic, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(lblTitle)
                        .addGap(51, 51, 51)
                        .addComponent(lblBluePlanePic, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(btnAddCustomer)
                        .addGap(62, 62, 62)
                        .addComponent(btnDisplayAll)
                        .addGap(42, 42, 42)
                        .addComponent(btnDisplayCustomersTotalPoints)
                        .addGap(47, 47, 47)
                        .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblSubtitle)))
                .addGap(0, 12, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblTitle)
                        .addComponent(lblRedPlanePic))
                    .addComponent(lblBluePlanePic))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblSubtitle)
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblFirstName)
                                    .addComponent(txtFirstName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(lblLastName))
                            .addComponent(txtLastName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblWeek1)
                            .addComponent(txtWeek1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblWeek2)
                            .addComponent(txtWeek2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblWeek3)
                            .addComponent(txtWeek3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblWeek4)
                            .addComponent(txtWeek4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAddCustomer)
                    .addComponent(btnDisplayAll)
                    .addComponent(btnDisplayCustomersTotalPoints)
                    .addComponent(btnExit))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        System.exit(0);  // This line of code causes the program to be exited if this button is pressed.
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnAddCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCustomerActionPerformed

        // The variables are declared.
        String firstName;
        String lastName;
        int week1;
        int week2;
        int week3;
        int week4;
        int firstNameIndex;
        int lastNameIndex;
        
        // A try catch statement used to ensure that the text gotten from the user can be parsed as an integer.
        try 
        {
                        
            // The variables of each value are initialized as the information input by the user.
            firstName = txtFirstName.getText();
            lastName = txtLastName.getText();
            week1 = Integer.parseInt(txtWeek1.getText());
            week2 = Integer.parseInt(txtWeek2.getText());
            week3 = Integer.parseInt(txtWeek3.getText());
            week4 = Integer.parseInt(txtWeek4.getText());
            
            if ((firstName.equals("")) || (lastName.equals("")))
            {
                txtOutput.setText("You have left a portion of the passenger's name blank. \n Please enter his/her full name and try again.");
            }
            
            else
            {
                // The index of the element which the user has inputted of both array is retrieved.
                firstNameIndex = firstNameArray.indexOf(firstName);
                lastNameIndex = lastNameArray.indexOf(lastName);
            
                // An if statement is used to determine if the value of the index is greater than negative 1 and if the last and first name indexes are the same. This determines if the user has already input the passenger's information.
                if ((firstNameIndex > -1) && (firstNameIndex == lastNameIndex))
                {
                    // An error output statement is used to explain to the user that they have already inputted information for the passenger.        
                    txtOutput.setText("Sorry. You have already entered previous information for this passenger.");
                }
                // An if statement is used so that if any of the integer values for the number of points per week is less than 0 an error message is outputted.
                else if ((week1 < 0) || (week2 < 0) || (week3 < 0) || (week4 < 0)) 
                {
                    // If the above case is true, an error statement is outputted.
                    txtOutput.setText("Sorry. You have not entered in a positive number of points.");
                
                }
            
                // An else statement is used if the if statement has not been used.
                else
                {
                    // The values gotten from the user from the text fields are then added to the end of the array list.
                    firstNameArray.add(firstName);
                    lastNameArray.add(lastName);
                    week1Array.add(week1);
                    week2Array.add(week2);
                    week3Array.add(week3);
                    week4Array.add(week4);
                }
            
            }
        }
        
        catch (Exception e) // The catch statement is used to catch any errors that may have happened if the user entered in a wrong piece of information.
        {
            // An error statement is outputted if the catch statement has to be used.
            txtOutput.setText("Sorry. You have not entered in the information correctly.\n This is either because you have entered a word instead of a number, left a points text field blank, or entered a decimal value.");
        }

        // All of the text fields are reset so that they display nothing within the text field.
        txtFirstName.setText("");
        txtLastName.setText("");
        txtWeek1.setText("");
        txtWeek2.setText("");
        txtWeek3.setText("");
        txtWeek4.setText("");


    }//GEN-LAST:event_btnAddCustomerActionPerformed

    private void btnDisplayAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayAllActionPerformed
        
        // The output text area is set to be blank when the user first pushes the button. This is in order to overwrite any previous information.
        txtOutput.setText("");
        
        // A for loop is used to go through all of the information of the array starting at the first value and going up to the array's size.
        for (int i = 0; i < firstNameArray.size(); i++) 
        {
            // An output statement is created displaying this information.
            txtOutput.append("" + firstNameArray.get(i) + " " + lastNameArray.get(i) + " " + week1Array.get(i) + " " + week2Array.get(i) + " " + week3Array.get(i) + " " + week4Array.get(i) + "\n");

        }

    }//GEN-LAST:event_btnDisplayAllActionPerformed

    private void btnDisplayCustomersTotalPointsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayCustomersTotalPointsActionPerformed
        // The integers are declared and initialized.
        int sum; // The sum is first set to 0.
        int target; // The variable of target is initialized as -1 because this value in the array does not exist. Therefore, if this is the case, the passenger will be unable to be found.
        int target1; 
        
        // The string variables are declared.
        String firstNameFound;
        String lastNameFound;
        
        // The variables of firstNameFound and lastNameFound are initialized as the information inputted by the user in the text fields for the passenger they would like to find.
        firstNameFound = txtFirstName.getText();
        lastNameFound = txtLastName.getText();

        // An if statement is used so that if the user does not input information in one of these text areas an error message is outputted.
        if ((firstNameFound.equals("")) || (lastNameFound.equals(""))) 
        {
            // If the above statement is true, an error message is outputted explaining that the 'blank' passenger cannot be found.
            txtOutput.setText("Sorry. You have left a field blank. \n The passenger you are searching for cannot be found.");
        }
        
        else
        {
            // The variables of target and target1 are initialized as the index value of where the name that the use is searching for is stored. 
            target = firstNameArray.indexOf(firstNameFound);
            target1 = lastNameArray.indexOf(lastNameFound);
        
            // An if statement is used to ensure that the target is not -1. This means that the passenger exists stored within the array and that the last and first name entered match up with that passenger.
            if ((target >= 0) && (target == target1))
            {
                // If the above condition is true, the program then gets the values within each array at the target in which the passenger was found and adds them together.
                sum = week1Array.get(target) + week2Array.get(target) + week3Array.get(target) + week4Array.get(target);
            
                // A nested if statement is used to determine if the above sum gotten is greater than the 5000 to determine if the passenger gets bonus points.
                if (sum > 5000) 
                {
                    // If the above condition is true the specific passenger's name is outputted with a statement declaring the number of points that they have with 1000 bonus points.
                    txtOutput.setText("" + firstNameArray.get(target) + " has " + sum + " points total and 1000 bonus points.");
                }
                // An else statement is used to determine if the sum is less than 5000.
                else 
                {
                    // If this else statement is used the passenger's points are displayed with 0 bonus points.
                    txtOutput.setText("" + firstNameArray.get(target) + " has " + sum + " points total and 0 bonus points.");
                }
        
            }
            else
            {
                txtOutput.setText("Sorry. " +firstNameFound+ " " +lastNameFound+ " could not be found within the database.");
            }
        }

    }//GEN-LAST:event_btnDisplayCustomersTotalPointsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ritter_FlightFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ritter_FlightFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ritter_FlightFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ritter_FlightFrm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ritter_FlightFrm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddCustomer;
    private javax.swing.JButton btnDisplayAll;
    private javax.swing.JButton btnDisplayCustomersTotalPoints;
    private javax.swing.JButton btnExit;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblBluePlanePic;
    private javax.swing.JLabel lblFirstName;
    private javax.swing.JLabel lblLastName;
    private javax.swing.JLabel lblRedPlanePic;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblWeek1;
    private javax.swing.JLabel lblWeek2;
    private javax.swing.JLabel lblWeek3;
    private javax.swing.JLabel lblWeek4;
    private javax.swing.JTextField txtFirstName;
    private javax.swing.JTextField txtLastName;
    private javax.swing.JTextArea txtOutput;
    private javax.swing.JTextField txtWeek1;
    private javax.swing.JTextField txtWeek2;
    private javax.swing.JTextField txtWeek3;
    private javax.swing.JTextField txtWeek4;
    // End of variables declaration//GEN-END:variables
}
